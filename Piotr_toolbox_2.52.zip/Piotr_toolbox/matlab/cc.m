% close all, clc
%
% USAGE
%  cc
%
% INPUTS
%
% OUTPUTS
%
% EXAMPLE
%
% See also C, CCC
%
% Piotr's Image&Video Toolbox      Version 1.5
% Copyright 2008 Piotr Dollar.  [pdollar-at-caltech.edu]
% Please email me if you find bugs, or have suggestions or questions!
% Licensed under the Lesser GPL [see external/lgpl.txt]

close all; clc
